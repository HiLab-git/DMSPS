# This file is classified as confidential level C3 within SenseTime Group
# -*- encoding: utf-8 -*-
'''
@File    :   itk_tools.py
@Time    :   2023/02/01
@Author  :   wuyu
@Contact :   wuyu2@sensetime.com
@Project :   med_utils
@Desc    :   An efficient library for medical image processing implemented in C++/CUDA
'''


import numpy as np
import SimpleITK as sitk


def bbox2border(bbox, size):
    bbox = np.array(bbox)
    size = np.array(size)
    borders = bbox.copy()
    borders[:, 1] = np.maximum(0, size - bbox[:, 1])
    return borders

def border2bbox(borders, size):
    borders = np.array(borders)
    size = np.array(size)
    bbox = borders.copy()
    bbox[:, 1] = np.maximum(bbox[:, 0], np.minimum(size, size - bbox[:, 1]))
    return bbox


def get_bbox_fast(np_mask, borders=0, is_ratio=False, stride=1):
    """
    :param np_mask: 二值化的mask
    :return: mask的bbox， (ndim, 2)
    """
    if not np.any(np_mask):
        return None
    ndim = np_mask.ndim
    if isinstance(borders, (float, int)):
        borders = [[borders, borders] for i in range(ndim)]
    temp = borders
    borders = []
    for i, b in enumerate(temp):
        if not hasattr(b, "__len__"):
            borders.append([b, b])
        else:
            borders.append(b)
    borders = np.array(borders)
    bbox = []
    for dim in range(ndim):
        axis = list(range(ndim))
        axis.pop(dim)
        nonzero_idx = np.nonzero(np.any(np_mask, axis=tuple(axis)))[0]
        bbox.append([nonzero_idx.min(), nonzero_idx.max()])
    bbox = np.array(bbox)
    if is_ratio:
        size = bbox[:, 1] - bbox[:, 0] + 1
        borders = borders * size[:, np.newaxis]
    borders = np.round(borders).astype(np.int32)
    bbox[:, 0] = np.minimum(np.maximum(0, bbox[:, 0] - borders[:, 0]), np.array(np_mask.shape) - 1)
    bbox[:, 1] = np.maximum(np.minimum(np.array(np_mask.shape) - 1, bbox[:, 1] + borders[:, 1]), bbox[:, 0])
    if stride > 1:
        size = bbox[:, 1] - bbox[:, 0] + 1
        target_size = (np.ceil(size / stride) * stride).astype(np.int32)
        stride_border = np.stack([(target_size - size) // 2, np.ceil((target_size - size) / 2).astype(np.int32)], axis=-1)
        bbox[:, 0] = np.maximum(bbox[:, 0] - stride_border[:, 0], 0)
        bbox[:, 1] = np.minimum(bbox[:, 1] + stride_border[:, 1], np.array(np_mask.shape) - 1)
    return bbox



def itk_redirection(itk_img, target_direction=(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)):
    # target direction should be orthognal, i.e. (1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)
    ndim = 3
    src_direction = itk_img.GetDirection()
    round_target_direction = np.round(np.array(target_direction)).reshape(ndim, ndim)
    round_src_direction = np.round(np.array(src_direction)).reshape(ndim, ndim)
    D = np.matmul(round_target_direction.T, round_src_direction)
    permute_axes = np.matmul(D, np.arange(1, ndim + 1)).round().astype(np.int32)
    abs_permute_axes = np.abs(permute_axes) - 1
    if(np.any(abs_permute_axes != np.arange(ndim, dtype=np.int32))):
        itk_img = sitk.PermuteAxes(itk_img, (abs_permute_axes).tolist())
    if(np.any(permute_axes < 0)):
        itk_img = sitk.Flip(itk_img, (permute_axes < 0).tolist())
    return itk_img


def np_redirection(np_zyx_arr, src_direction=(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0), target_direction=(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)):
    # src_direction / target direction should be orthognal, i.e. (1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)
    ndim = np_zyx_arr.ndim
    round_target_direction = np.round(np.array(target_direction)).reshape(ndim, ndim)
    round_src_direction = np.round(np.array(src_direction)).reshape(ndim, ndim)
    D = np.matmul(round_target_direction.T, round_src_direction)
    permute_axes = np.matmul(D, np.arange(1, ndim + 1)).round().astype(np.int32)
    rev_pemt_axes = permute_axes[::-1]
    zyx_rev_pemt_axes = np.sign(rev_pemt_axes) * (ndim + 1 - np.abs(rev_pemt_axes))
    np_zyx_arr = np_zyx_arr.transpose(np.abs(zyx_rev_pemt_axes) - 1)
    np_zyx_arr = np.flip(np_zyx_arr, np.where(zyx_rev_pemt_axes < 0)[0])
    return np_zyx_arr


def border_redirection(xyz_borders, src_direction=(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0), target_direction=(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)):
    # src_direction / target direction should be orthognal, i.e. (1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)
    ndim = xyz_borders.shape[0]
    xyz_borders = xyz_borders.copy()
    round_target_direction = np.round(np.array(target_direction)).reshape(ndim, ndim)
    round_src_direction = np.round(np.array(src_direction)).reshape(ndim, ndim)
    D = np.matmul(round_target_direction.T, round_src_direction)
    permute_axes = np.matmul(D, np.arange(1, ndim + 1)).round().astype(np.int32)
    xyz_borders = xyz_borders[np.abs(permute_axes) - 1]
    for i, ax in enumerate(permute_axes):
        if ax < 0:
            xyz_borders[i] = xyz_borders[i][::-1]
    return xyz_borders


def pad_nda_w_direction(zyx_nda, xyz_borders, 
                    nda_direction=(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0), 
                    border_direction=(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0),
                    target_direction=(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)):
    xyz_borders = np.array(xyz_borders)
    assert np.all(xyz_borders >= 0), "borders should not be negative!" 
    xyz_borders = border_redirection(xyz_borders, src_direction=border_direction, target_direction=target_direction)
    zyx_nda = np_redirection(zyx_nda, src_direction=nda_direction, target_direction=target_direction)
    zyx_borders = xyz_borders[::-1]
    return np.pad(zyx_nda, zyx_borders.tolist(), mode="constant", constant_values=0)


def resample_image_w_border(src_itk, xyz_borders, interpolate_method='NearestNeighbor'):
    xyz_borders = np.array(xyz_borders)
    assert np.all(xyz_borders >= 0), "borders should not be negative!" 
    assert interpolate_method in ['Linear', 'NearestNeighbor']

    src_size = np.array(src_itk.GetSize())
    re_sample_size = src_size + xyz_borders.sum(axis=1)
    re_sample_origin = src_itk.TransformContinuousIndexToPhysicalPoint((-xyz_borders[:, 0]).tolist())

    re_sampler = sitk.ResampleImageFilter()
    re_sampler.SetOutputPixelType(src_itk.GetPixelID())
    re_sampler.SetReferenceImage(src_itk)
    re_sampler.SetSize(re_sample_size.astype(np.int32).tolist())
    re_sampler.SetOutputOrigin(re_sample_origin)
    re_sampler.SetInterpolator(eval('sitk.sitk' + interpolate_method))
    return re_sampler.Execute(src_itk)

__all__ = [
    "bbox2border", 
    "border2bbox", 
    "itk_redirection", 
    "np_redirection", 
    "border_redirection", 
    "resample_image_w_border",
    "get_bbox_fast",
    "pad_nda_w_direction"
    ]